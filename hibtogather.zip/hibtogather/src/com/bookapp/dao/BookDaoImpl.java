package com.bookapp.dao;

import java.util.*;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class BookDaoImpl implements BookDao {

	private SessionFactory factory;

	public BookDaoImpl() {
		factory = HibernateSessionFactory.getSessionFactory();
	}

	@Override
	public List<Book> getAllBooks() {
		Session session = factory.openSession();
		List<Book> books = session.createQuery("from Book").list();
		session.close();
		return books;
	}

	@Override
	public void addBook(Book book) {
		Session session = factory.openSession();
		Transaction tx = session.getTransaction();
		try {
			tx.begin();
			session.save(book);
			tx.commit();
		} catch (HibernateException ex) {
			tx.rollback();
		}
		session.close();

	}

	@Override
	public void deleteBook(int id) {
		Session session = factory.openSession();
		Transaction tx = session.getTransaction();
		try {
			tx.begin();
			Book book=getBookById(id);
			session.delete(book);
			tx.commit();
		} catch (HibernateException ex) {
			tx.rollback();
		}
		session.close();
	}

	@Override
	public void updateBook(int id, Book book) {
		Session session = factory.openSession();
		Transaction tx = session.getTransaction();
		try {
			tx.begin();
			Book bookToUpdated=getBookById(id);
			bookToUpdated.setPrice(book.getPrice());
			session.update(bookToUpdated);
			tx.commit();
		} catch (HibernateException ex) {
			tx.rollback();
		}
		session.close();
	}

	@Override
	public Book getBookById(int id) {
		Session session = factory.openSession();
		Book book = session.get(Book.class, id);
		session.close();
		if (book != null)
			return book;
		else
			throw new BookNotFoundException("book with id:" + id +" is not found");
	}
}
