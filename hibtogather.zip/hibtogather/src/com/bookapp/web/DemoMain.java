package com.bookapp.web;

import com.bookapp.dao.Book;
import com.bookapp.dao.BookDao;
import com.bookapp.dao.BookDaoImpl;
import java.util.*;
public class DemoMain {

	public static void main(String[] args) {
		BookDao dao=new BookDaoImpl();
		List<Book> books=dao.getAllBooks();
		books.forEach(book-> System.out.println(book));
	}
}
