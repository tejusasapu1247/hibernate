package com.composite;

import java.util.Date;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.bookapp.dao.HibernateSessionFactory;

public class DemoComposite {

	public static void main(String[] args) {
		SessionFactory factory = HibernateSessionFactory.getSessionFactory();

		Session session = factory.openSession();

		BookId id = new BookId("ASW23", "java");
		Book book = new Book(id, "rajeev", new Date(), 350);

		Transaction tx = session.getTransaction();

		try {
			tx.begin();
			session.save(book);
			tx.commit();
		} catch (HibernateException ex) {
			tx.rollback();
		}

	}
}
