package com.demo;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.service.ServiceRegistry;

public class AddBook {

	public static void main(String[] args) throws ParseException {
		ServiceRegistry serviceRegistry=new StandardServiceRegistryBuilder()
				.configure("hibernate.cfg.xml").build();
		SessionFactory factory=
				new MetadataSources(serviceRegistry)
				.buildMetadata().buildSessionFactory();
		//Session
		
		Session session=factory.openSession(); //openSession() vs getCurrentSession()
		SimpleDateFormat fmt=new SimpleDateFormat("dd/MM/yyyy");
		
		session.getTransaction().begin();
		Book book1=new Book("EQ123", "effective java", "abc", fmt.parse("12/11/2014"), 600);
		Book book2=new Book("EQ623", "basic of physics", "foo", fmt.parse("2/11/2017"), 400);
		Book book3=new Book("EF193", "spring framework", "raj", fmt.parse("12/11/2019"), 500);
		
		session.save(book1);
		session.save(book2);
		session.save(book3);
		
		session.getTransaction().commit();
		
		session.close();
		factory.close();
	}
}



