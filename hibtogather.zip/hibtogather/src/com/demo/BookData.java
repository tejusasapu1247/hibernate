package com.demo;

public class BookData {
	private String title;
	private double price;
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public BookData(String title, double price) {
		System.out.println("hib is calling it");
		this.title = title;
		this.price = price;
	}
	public BookData() {}
	@Override
	public String toString() {
		return "BookData [title=" + title + ", price=" + price + "]";
	}
	
	
}
