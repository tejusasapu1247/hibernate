package com.demo;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.service.ServiceRegistry;

public class DelBook {

	public static void main(String[] args) throws ParseException {
		ServiceRegistry serviceRegistry=new StandardServiceRegistryBuilder()
				.configure("hibernate.cfg.xml").build();
		SessionFactory factory=
				new MetadataSources(serviceRegistry)
				.buildMetadata().buildSessionFactory();
		//Session
		
		Session session=factory.openSession();
		
		session.getTransaction().begin();
		
		Book bookToBedelete=session.get(Book.class, 2);
		if(bookToBedelete!=null) {
			session.delete(bookToBedelete);
		}
		
		session.getTransaction().commit();
		
		session.close();
		factory.close();
	}
}



