package com.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.service.ServiceRegistry;
import java.util.*;
public class ShowAll {

	public static void main(String[] args) {
		//SessionFactory
		
		ServiceRegistry serviceRegistry=new StandardServiceRegistryBuilder()
				.configure("hibernate.cfg.xml").build();
		SessionFactory factory=new MetadataSources(serviceRegistry)
				.buildMetadata().buildSessionFactory();
		
		Session session=factory.openSession();
		
		//get all books: no tx is req
		
		//HQL vs SQL
		
		//from Book
		//select b from Book b
		
		/*List<BookData> books=session.createQuery
				("select new com.demo.BookData(b.title, b.price) from Book b")
				.list();
		books.forEach(bd-> System.out.println(bd));*/
	/*	for(Object[] temp: books) {
			System.out.println(temp[0]+": "+ temp[1]);
		}*/
		
		List<Book> books=session.createQuery
				("select b from Book b where b.id=:id")
				.setParameter("id", 3)
				.list();
		books.forEach(b-> System.out.println(b));
		
		session.close();
		factory.close();
		
	}
}




