package com.lifecycle;
import java.util.*;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.bookapp.dao.HibernateSessionFactory;

public class Tester {

	public static void main(String[] args) {
		SessionFactory factory=HibernateSessionFactory.getSessionFactory();
		
		//flush operation
		// let say u have loaded an customer and want to update it
		//but commit is there after 100 lines, u want to hit db immeditly... flush operation
		//the db is only going to commit after ur commit operation
		
		Session session1=factory.openSession();
		session1.getTransaction().begin();
		Customer customer=session1.get(Customer.class, 5);
		customer.setAddress("nirman vihar phase 2");
		
		
		session1.update(customer);
		session1.flush(); //it is used to hit database out of turn , ie it dont wait for commit operation
		//rec is in dirty state, if somebody else want to read that rec mysql do not show it ( as it maintain dirty state checking)
		
		try {
			Thread.sleep(10000);
		}catch(InterruptedException ex) {
			
		}
		
		System.out.println("comes out of sleep");
		session1.getTransaction().commit();
		
		//refresh method
//		Session session1=factory.openSession();
//		Customer customer=session1.get(Customer.class, 5);
//		System.out.println(customer);
//		try {
//			Thread.sleep(10000);
//		}catch(InterruptedException ex) {
//			
//		}
//		session1.refresh(customer);
//		System.out.println(customer);
		//update and merge (merge is more better to use as compared to update)
		
//		Session session1=factory.openSession();
//		Customer customer=session1.get(Customer.class, 5);
//		session1.close();
//		customer.setAddress("chennai1");
//		
//		Session session2=factory.openSession();
//		session2.getTransaction().begin();
//		Customer customer2=session2.get(Customer.class, 5);
//		customer2.setAddress("new chennai1");
//		customer2.setName("umesh sharma");
//		session2.update(customer);
//		session2.getTransaction().commit();
//		session2.close();
		
		
		
		//get vs load
//		Session session=factory.openSession();
//		//Get is eager fetch str.
//		//load is lazy fetch str.: it will give u a proxy object
//		Customer customer=session.load(Customer.class, 50);
//		session.close();
//		System.out.println(customer);
		
		
		//factory.close();
		
		/*//getCurrentSession 		vs	 openSession
		//used with spring	
		
		//getCurrentSession: in this hibernate will create a session and bind with the current
		//thread ie mean u dnot have to open the session and close the session
		
		Session session=factory.getCurrentSession();
		//session.getTransaction().begin();
		List<Customer>customers=session.createQuery("from Customer").list();
		customers.forEach(c-> System.out.println(c));
		//session.getTransaction().commit();
		session.close();
		factory.close();*/
		
//		//transient , persistend , detached
//		
//		//tran: hibreante dont know about this object
//		Customer customer=new Customer("umesh", "noida");
//		
//		Transaction tx=session.getTransaction();
//		
//		try {
//			tx.begin();
//			//persisted
//			session.persist(customer);
//			tx.commit();
//		}catch(HibernateException ex) {
//			tx.rollback();
//		}
//		
//		
//		session.close();
//		// customer object become detached....
//		factory.close();
		
		
	}
}









