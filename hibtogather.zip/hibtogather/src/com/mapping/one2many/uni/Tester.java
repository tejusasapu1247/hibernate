package com.mapping.one2many.uni;
import java.util.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.bookapp.dao.HibernateSessionFactory;
import java.util.*;
public class Tester {

	public static void main(String[] args) {
		SessionFactory factory = HibernateSessionFactory.getSessionFactory();

		Session session = factory.openSession();

		session.getTransaction().begin();
		
		List<Department> depts=session.createQuery("select d from Department d").list();
		
		for(Department d: depts) {
			System.out.println(d.getDetpName());
			System.out.println("-------------------------");
			 for(Employee e: d.getEmployees()) {
				 System.out.println(e);
			 }
			System.out.println("-------------------------");
		}
		
	/*
		Department department=new Department("HCL training chennai");
		Employee employee1=new Employee("raja");
		Employee employee2=new Employee("amit");
		Employee employee3=new Employee("gunika");
		
		department.getEmployees().add(employee1);
		department.getEmployees().add(employee2);
		department.getEmployees().add(employee3);
		
		
		Department department2=new Department("HCL fin dept chennai");
		Employee employee4=new Employee("umesh");
		Employee employee5=new Employee("kapil");
		Employee employee6=new Employee("pooja");
		
		department2.getEmployees().add(employee4);
		department2.getEmployees().add(employee5);
		department2.getEmployees().add(employee6);
		
		
		Department department3=new Department("HCL sales dept chennai");
		Employee employee7=new Employee("mukesh");
		Employee employee8=new Employee("tarun");
		
		
		department2.getEmployees().add(employee4);
		department2.getEmployees().add(employee5);
		department2.getEmployees().add(employee6);
		
		session.save(department);
		session.save(department2);
		session.save(department3);
		*/
		session.getTransaction().commit();
		session.close();

		factory.close();
	}

}
