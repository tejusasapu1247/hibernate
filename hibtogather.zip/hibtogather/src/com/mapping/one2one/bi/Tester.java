package com.mapping.one2one.bi;
import java.util.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.bookapp.dao.HibernateSessionFactory;

public class Tester {

	public static void main(String[] args) {
		SessionFactory factory = HibernateSessionFactory.getSessionFactory();

		Session session = factory.openSession();

		session.getTransaction().begin();
		
	/*	List<Parking> parkings=session.createQuery("from Parking").list();
		for(Parking parking: parkings) {
			System.out.println(parking.getParkingLocation());
			System.out.println(parking.getEmployee().getEmpName());
		}*/
		//from Parking p join fetch p.employee Employee
		List<Employee> emps=session.createQuery("from Employee e join fetch e.parking Parking").list();
		for(Employee emp: emps) {
			System.out.println(emp.getParking().getParkingLocation());
			System.out.println(emp.getEmpName());
		}
		
		
//		Parking parking=session.get(Parking.class, 1);
//		session.delete(parking);
		
		
//		Parking parking1=new Parking("I34");
//		Employee employee1=new Employee("sumit");
//		
//		Parking parking2=new Parking("M76");
//		Employee employee2=new Employee("ravi");
//		
//		Parking parking3=new Parking("E31");
//		Employee employee3=new Employee("hari");
//		
//		parking1.setEmployee(employee1);
//		employee1.setParking(parking1);
//		
//		parking2.setEmployee(employee2);
//		employee2.setParking(parking2);
//		
//		parking3.setEmployee(employee3);
//		employee3.setParking(parking3);
//		
//		
//		
//		//session.save(employee1);
//		session.save(parking1);
//		
//		//session.save(employee2);
//		session.save(parking2);
//		
//		//session.save(employee3);
//		session.save(parking3);
//		
		
		session.getTransaction().commit();
		session.close();
		
		
		
		
		//List<Parking> list=session.createQuery("from Parking p join fetch p.employee Employee").list();
		/*List<Employee> employees=session.createQuery
				("select e from Employee e join fetch e.parking Parking").list();
		for(Employee emp: employees) {
			System.out.println(emp.getEmpName());
			System.out.println(emp.getParking());
		}*/
	
		
		

		// Parking parking1=new Parking("I34");
		// Employee employee1=new Employee("sumit", parking1);
		//
		// Parking parking2=new Parking("M76");
		// Employee employee2=new Employee("ravi", parking2);
		//
		// Parking parking3=new Parking("E31");
		// Employee employee3=new Employee("hari", parking3);
		//
		//
		//
		// session.save(employee1);
		// //session.save(parking1);
		//
		// session.save(employee2);
		// //session.save(parking2);
		//
		// session.save(employee3);
		// //session.save(parking3);
		//
		//

		factory.close();
	}

}
