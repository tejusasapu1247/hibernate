package com.mapping.one2one.uni;
import java.util.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.bookapp.dao.HibernateSessionFactory;

public class Tester {

	public static void main(String[] args) {
		SessionFactory factory = HibernateSessionFactory.getSessionFactory();

		Session session = factory.openSession();

		session.getTransaction().begin();
		//List<Parking> list=session.createQuery("from Parking p join fetch p.employee Employee").list();
		List<Employee> employees=session.createQuery
				("select e from Employee e join fetch e.parking Parking").list();
		for(Employee emp: employees) {
			System.out.println(emp.getEmpName());
			System.out.println(emp.getParking());
		}
		session.getTransaction().commit();
		session.close();
		
		

		// Parking parking1=new Parking("I34");
		// Employee employee1=new Employee("sumit", parking1);
		//
		// Parking parking2=new Parking("M76");
		// Employee employee2=new Employee("ravi", parking2);
		//
		// Parking parking3=new Parking("E31");
		// Employee employee3=new Employee("hari", parking3);
		//
		//
		//
		// session.save(employee1);
		// //session.save(parking1);
		//
		// session.save(employee2);
		// //session.save(parking2);
		//
		// session.save(employee3);
		// //session.save(parking3);
		//
		//

		factory.close();
	}

}
