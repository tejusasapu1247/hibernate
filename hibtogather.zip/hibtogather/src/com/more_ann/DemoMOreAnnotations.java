package com.more_ann;

import java.util.Date;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.bookapp.dao.HibernateSessionFactory;

public class DemoMOreAnnotations {

	public static void main(String[] args) {
		
		SessionFactory factory=HibernateSessionFactory.getSessionFactory();
		
		Book book=new Book("RA123", "java", "Raj", new Date(), 300);
		
		Session session=factory.openSession();
		
		Transaction tx=session.getTransaction();
		
		try {
			tx.begin();
			 session.save(book);
			tx.commit();
		}catch(HibernateException ex) {
			tx.rollback();
		}
		
		session.close();
		factory.close();
	}
}







