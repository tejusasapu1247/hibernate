package com.one_class_2_table;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.bookapp.dao.HibernateSessionFactory;

public class Tester {

	public static void main(String[] args) {
		SessionFactory factory=HibernateSessionFactory.getSessionFactory();
		Session session=factory.openSession();
		session.getTransaction().begin();
		Customer customer=new Customer("rajesh"	, "banglore", "34545454554", "r@r.com");
		session.save(customer);
		session.getTransaction().commit();
		
		session.close();
		factory.close();
	}
}
